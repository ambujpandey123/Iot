sudo apt install python3-pyaudio -y

sudo apt install flac -y
 
sudo pip3 install speechrecognition

sudo usermod -a -G spi,gpio pi

sudo apt install build-essential python3-dev python3-pip libfreetype6-dev libjpeg-dev libopenjp2-7 libtiff5 -y

sudo pip3 install setuptools

sudo pip3 install --upgrade luma.led_matrix


sudo apt install python3-pyaudio -y

sudo apt install flac -y

sudo pip3 install speechrecognition

